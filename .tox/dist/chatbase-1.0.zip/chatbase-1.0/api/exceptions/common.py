class GenericException(Exception):
    pass

class ConfigException(Exception):
    pass